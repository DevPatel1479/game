import * as THREE from '../build/three.module.js';
import { OrbitControls } from '../build/OrbitControls.js';
import { Water } from '../build/Water.js';

const scene = new THREE.Scene();
// scene.background = new THREE.Color('aqua');
// scene.fog = new THREE.Fog( 0xa0a0a0, 10, 50 );
// const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
// camera.position.set(0, 5, 10);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const container = new THREE.Group();
scene.add(container);
const xAxis = new THREE.Vector3(1, 0, 0);
const tempCameraVector = new THREE.Vector3();
const tempModelVector = new THREE.Vector3();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.01, 1000 );
camera.position.set( 0, 2, -1 );
const cameraOrigin = new THREE.Vector3(0, 1.5, 0);
camera.lookAt(cameraOrigin);
container.add(camera);




const cubeGeometry = new THREE.BoxGeometry(1, 1, 1);
const cubeMaterial = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);

cube.position.y = 0;

scene.add(cube);

// const planeGeometry = new THREE.PlaneGeometry(10, 10);
// const planeMaterial = new THREE.MeshBasicMaterial({ color: 0xaaaaaa, side: THREE.DoubleSide });
// const plane = new THREE.Mesh(planeGeometry, planeMaterial);
// plane.rotation.x = Math.PI/2;
// scene.add(plane);

const waterGeometry = new THREE.PlaneGeometry(100, 100);
const water = new Water(waterGeometry, {
  textureWidth: 512,
  textureHeight: 512,
  waterNormals: new THREE.TextureLoader().load('../project/water.jpg', function(texture) {
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  }),
  alpha: 1.0,
  sunDirection: new THREE.Vector3(),
  sunColor: 'yellow',
  waterColor: '#2389da',
  distortionScale: 3.5,
});
water.rotation.x = -Math.PI / 2;
scene.add(water);

// const controls = new OrbitControls(camera, renderer.domElement);
// controls.target.set(0, 1, 0);

// Arrow key controls
const moveSpeed = 4.5;
let moveForward = false;
let mousedown = false;
let clock;
clock = new THREE.Clock();

// document.addEventListener('keypress', (event) => {
//   switch (event.code) {
//     case 'KeyW':
//       moveForward = true;
//       cube.position.z -= moveSpeed;
//       break;
//     case 'KeyS':
//       moveForward =
//       cube.position.z += moveSpeed;
//       break;
//     case 'KeyA':
//       cube.position.x -= moveSpeed;
    
//       break;
//     case 'KeyD':
//       cube.position.x += moveSpeed;
//       break;
//   }
// });

let mixer = new THREE.AnimationMixer( cube );

const animate = () => {
  requestAnimationFrame(animate);
  // Update the controls
  // controls.update();
  if(mixer) {
    const mixerUpdateDelta = clock.getDelta();
    mixer.update( mixerUpdateDelta );
  }

  if (moveForward){

    camera.getWorldDirection(tempCameraVector);

    const cameraDirection = tempCameraVector.setY(0).normalize();
  
    // Get the X-Z plane in which player is looking to compare with camera
    cube.getWorldDirection(tempModelVector);
    const playerDirection = tempModelVector.setY(0).normalize();

    // Get the angle to x-axis. z component is used to compare if the angle is clockwise or anticlockwise since angleTo returns a positive value
    const cameraAngle = cameraDirection.angleTo(xAxis) * (cameraDirection.z > 0 ? 1 : -1);
    const playerAngle = playerDirection.angleTo(xAxis) * (playerDirection.z > 0 ? 1 : -1);
    
    // Get the angle to rotate the player to face the camera. Clockwise positive
    const angleToRotate = playerAngle - cameraAngle;
    
    // Get the shortest angle from clockwise angle to ensure the player always rotates the shortest angle
    let sanitisedAngle = angleToRotate;
    if(angleToRotate > Math.PI) {
      sanitisedAngle = angleToRotate - 2 * Math.PI
    }
    if(angleToRotate < -Math.PI) {
      sanitisedAngle = angleToRotate + 2 * Math.PI
    }
    cube.rotateY(
      Math.max(-0.05, Math.min(sanitisedAngle, 0.05))
    );
    container.position.add(cameraDirection.multiplyScalar(0.05));
    camera.lookAt(container.position.clone().add(cameraOrigin));
    
  }
  // Update camera position to follow the cube
  // camera.position.copy(cube.position);
  // camera.position.add(new THREE.Vector3(0, 4, 5));
  // camera.lookAt(cube.position);

  water.material.uniforms['time'].value += 2 / 60.0;

  renderer.render(scene, camera);
};

animate();


window.addEventListener("keydown", (e) => {
  if(e.code == 'KeyA' || e.code === 'KeyW') {
  
    moveForward = true;
  }
});

window.addEventListener("keyup", (e) => {
  if(e.code === 87 || e.code === 38) {
   
    moveForward = false;
  }
});

window.addEventListener("pointerdown", (e) => {
  mousedown = true;
});

window.addEventListener("pointerup", (e) => {
  mousedown = false;
});

window.addEventListener("pointermove", (e) => {
  if(mousedown) {
    const { movementX, movementY} = e;
    const offset = new THREE.Spherical().setFromVector3(
      camera.position.clone().sub(cameraOrigin)
    );
    
    const phi = offset.phi - movementY * 0.02;
    offset.theta -= movementX * 0.02;
    offset.phi = Math.max(0.01, Math.min(0.35 * Math.PI, phi));
    camera.position.copy(
      cameraOrigin.clone().add(new THREE.Vector3().setFromSpherical(offset))
    );
    camera.lookAt(container.position.clone().add(cameraOrigin));
  }
});