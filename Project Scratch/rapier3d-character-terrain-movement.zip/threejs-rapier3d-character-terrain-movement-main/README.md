# threejs-rapier3d-character-terrain-movement

`npm install` and `npm run start`  
  
Try the [Stackblitz](https://stackblitz.com/github/tamani-coding/threejs-rapier3d-character-terrain-movement)  
  
![Screenshot](https://github.com/tamani-coding/threejs-rapier3d-character-terrain-movement/blob/main/screenshot01.png?raw=true)

## sources

Model from: https://threejs.org/examples/#webgl_animation_skinning_blending
Textures from: https://3dtextures.me/