import { Vector3 } from './math/Vector3.js';

export const WorldUp = new Vector3( 0, 1, 0 );
