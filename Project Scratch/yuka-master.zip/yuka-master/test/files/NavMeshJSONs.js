/**
* @author {@link https://github.com/Mugen87|Mugen87}
*/
module.exports = {
	CostTable: { "nodes": [ { "index": 0, "costs": [[ 0, 0 ], [ 1, 0.9428090415820634 ]] }, { "index": 1, "costs": [[ 0, 0.9428090415820634 ], [ 1, 0 ]] } ] },
};
