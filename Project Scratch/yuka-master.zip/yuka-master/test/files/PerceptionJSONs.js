/**
* @author {@link https://github.com/Mugen87|Mugen87}
*/
module.exports = {
	MemoryRecord: { "type": "MemoryRecord", "entity": "4C06581E-448A-4557-835E-7A9D2CE20D30", "timeBecameVisible": "-Infinity", "timeLastSensed": "-Infinity", "lastSensedPosition": [ 0, 0, 0 ], "visible": false },
	MemorySystem: { "type": "MemorySystem", "owner": "4C06581E-448A-4557-835E-7A9D2CE20D30", "records": [ { "type": "MemoryRecord", "entity": "52A33A16-6843-4C98-9A8E-9FCEA255A481", "timeBecameVisible": "-Infinity", "timeLastSensed": "-Infinity", "lastSensedPosition": [ 0, 0, 0 ], "visible": false } ], "memorySpan": 1 },
	Vision: { "type": "Vision", "owner": "4C06581E-448A-4557-835E-7A9D2CE20D30", "fieldOfView": 0.7853981633974483, "range": "3", "obstacles": [ "4C06581E-448A-4557-835E-7A9D2CE20D31" ] }
};
