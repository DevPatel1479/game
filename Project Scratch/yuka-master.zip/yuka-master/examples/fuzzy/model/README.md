Assault Rifle from https://sketchfab.com/3d-models/sci-fi-assault-rifle-d2596ed504b84ffda761b0886c26b202 by Ptis
License: CC Attribution-NonCommercial
