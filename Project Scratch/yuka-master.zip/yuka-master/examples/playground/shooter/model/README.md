SciFi Gun from https://sketchfab.com/models/04a9f3ccb5b14dc38a28b27c1916e18e by Feche Pedroza
License: CC Attribution

Target (Hackathon tournament) from https://sketchfab.com/models/e2f631c75c83440887d2613fe4aeb84c by NikiYani
License: CC Attribution
