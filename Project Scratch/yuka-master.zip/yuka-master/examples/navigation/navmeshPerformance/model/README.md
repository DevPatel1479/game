Model from https://sketchfab.com/models/7842d43173c54ec18da10246cdc6da71 by hansolocambo
License: CC Attribution
