Model from https://sketchfab.com/models/645533aee9f448b8b20e1f4fb4b472ca by linhtatoo
License: CC Attribution
