Robot from https://sketchfab.com/3d-models/robo-obj-pose4-uaeYu2fwakD1e1bWp5Cxu3XAqrt by Artem Shupa-Dubrova
License: CC Attribution-NoDerivs
