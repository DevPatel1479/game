# Security Policy

## Supported Versions

We only support the latest major version with security updates.

## Reporting a Vulnerability

Please report a vulnerability to: michael.herzog@human-interactive.org
